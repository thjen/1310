﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1110
{
    public class Thuoc
    {
        private string _MaHang;
        private string _TenHang;
        private string _NhaSanXuat;
        private DateTime? _HanSuDung;
        private string _NhomThuoc;

        public string MaHang { get { return _MaHang; } set { _MaHang = value; } }
        public string TenHang { get { return _TenHang; } set { _TenHang = value; } }
        public string NhaSanXuat { get { return _NhaSanXuat; } set { _NhaSanXuat = value; } }
        public DateTime? HanSuDung { get { return _HanSuDung; } set { _HanSuDung = value; } }
        public string NhomThuoc { get { return _NhomThuoc; } set { _NhomThuoc = value; } }
       
    }
}
