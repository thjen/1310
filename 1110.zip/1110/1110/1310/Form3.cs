﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1110._1310
{
    public partial class Form3 : Form
    {
        List<string> dp = new List<string>();
        public Form3()
        {
            InitializeComponent();
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbMaHang.Text != "" && tbTenHang.Text != "")
                {
                    string nhomThuoc = "";
                    if (rbKhangSinh.Checked)
                        nhomThuoc = "Kháng sinh";
                    if (rbThucPhamChucNang.Checked)
                        nhomThuoc = "Thực phẩm chức năng";
                    if (rbThuocDacTri.Checked)
                        nhomThuoc = "Thuốc đặc trị";

                    DuocPham duocPham = new DuocPham(tbMaHang.Text, tbTenHang.Text, cbNhaSanXuat.Text, Convert.ToDateTime(dtpHanSuDung.Text), nhomThuoc);
                    dp = duocPham.XuatDuLieu();
                    LoadList();
                }
                else throw new Exception("Nhập thiếu");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LoadList()
        {            
            string[] strs = new string[dp.Count];
            int i = 0;
            foreach(var el in dp)
            {
                strs[i] = el;
                i++;
            }
            listThuoc.Items.Add(new ListViewItem(strs));
            listThuoc.GridLines = true;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            listThuoc.Columns.Add("Mã hàng");
            listThuoc.Columns.Add("Tên hàng");
            listThuoc.Columns.Add("Nhà sản xuất");
            listThuoc.Columns.Add("Nhóm thuốc");
            listThuoc.Columns.Add("Hạn sử dụng");
        }
    }
}
