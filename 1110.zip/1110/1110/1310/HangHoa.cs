﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1110._1310
{
    public class HangHoa
    {
        private string _MaHang;
        private string _TenHang;
        private string _NhaSanXuat;

        public HangHoa(string mahang, string tenhang, string nsx)
        {
            this.MaHang = mahang;
            this.TenHang = tenhang;
            this.NhaSanXuat = nsx;
        }

        public string MaHang { get { return _MaHang; } set { _MaHang = value; } }
        public string TenHang { get { return _TenHang; } set { _TenHang = value; } }
        public string NhaSanXuat { get { return _NhaSanXuat; } set { _NhaSanXuat = value; } }

        public virtual List<string> XuatDuLieu()
        {
            List<string> list = new List<string>();
            list.Add(MaHang);
            list.Add(TenHang);
            list.Add(NhaSanXuat);
            return list;
        }
    }
}
