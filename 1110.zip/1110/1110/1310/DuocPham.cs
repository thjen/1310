﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1110._1310
{
    public class DuocPham : HangHoa
    {
        private DateTime? _HanSuDung;
        private string _NhomThuoc;

        public DateTime? HanSuDung { get { return _HanSuDung; } set { _HanSuDung = value; } }
        public string NhomThuoc { get { return _NhomThuoc; } set { _NhomThuoc = value; } }

        public DuocPham(string mahang, string tenhang, string nsx, DateTime? hsd, string nhomthuoc) : base(mahang, tenhang, nsx)
        {
            this.HanSuDung = hsd;
            this.NhomThuoc = nhomthuoc;
        }

        public override List<string> XuatDuLieu()
        {
            List<string> duocPham = new List<string>();
            foreach(var item in base.XuatDuLieu())
            {
                duocPham.Add(item);
            }
            duocPham.Add(HanSuDung + "");
            duocPham.Add(NhomThuoc);
            return duocPham;
        }
    }
}
